package views;


import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.*;
import org.eclipse.wb.swt.SWTResourceManager;

import edu.mit.csail.sdg.alloy4.Err;
import handlers.UML2Alloy_Verify;
import utils.XMLFileFilter;

import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;

import org.dom4j.DocumentException;
import org.eclipse.ui.*;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.inject.Inject;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class SCKPISecView extends ViewPart {
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private Text text_4;
	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "views.SCKPISecView";

	@Inject IWorkbench workbench;
	@Override
	public void createPartControl(Composite parent) {

		try {
			todo(parent);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void todo(Composite parent) throws DocumentException{

		TabFolder tabFolder = new TabFolder(parent,SWT.BORDER);
		TabItem tabItem1 = new TabItem(tabFolder, SWT.NONE);
		tabItem1.setText("SCKPISec Verification");

		Composite compsoite1 = new Composite(tabFolder,SWT.None);
        tabItem1.setControl(compsoite1);
        
        compsoite1.setLayout(new GridLayout(3, false));
		GridData gd_tabFolder = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_tabFolder.heightHint = 45;
		tabFolder.setLayoutData(gd_tabFolder);
		
		Label lblNewLabel = new Label(compsoite1, SWT.NONE);
		lblNewLabel.setAlignment(SWT.LEFT);
		lblNewLabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblNewLabel.setText("Choose UML Models:");
		lblNewLabel.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		new Label(compsoite1, SWT.NONE);
		new Label(compsoite1, SWT.NONE);
		
		text = new Text(compsoite1, SWT.BORDER);
		GridData gd_text = new GridData(SWT.LEFT, SWT.CENTER, true, false, 2, 1);
		gd_text.widthHint = 594;
		text.setLayoutData(gd_text);
		text.setBackground(SWTResourceManager.getColor(240, 248, 255));

		Button btnNewButton = new Button(compsoite1, SWT.NONE);
		GridData gd_btnNewButton = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNewButton.widthHint = 185;
		btnNewButton.setLayoutData(gd_btnNewButton);
		btnNewButton.setText("Choose Mission Model");
		btnNewButton.setBackground(SWTResourceManager.getColor(70,130,180));
		btnNewButton.setForeground(SWTResourceManager.getColor(255,255,255));
		btnNewButton.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		btnNewButton.addSelectionListener(new SelectionAdapter() {
		public void widgetSelected(SelectionEvent e) {
			    String taskModelFileName = "";
				JFrame frame = new JFrame();
				String dir = "C:\\Users\\15857\\workspace-papyrus";
				
				JFileChooser chooser = new JFileChooser();
				chooser.setCurrentDirectory(new File(dir));
				chooser.setDialogTitle("Choose UML model"); 	
			    XMLFileFilter xmlFilter = new XMLFileFilter();   
			    chooser.addChoosableFileFilter(xmlFilter);
			    chooser.setFileFilter(xmlFilter);

				int flag = chooser.showOpenDialog(frame);
				if (flag == JFileChooser.APPROVE_OPTION) {
					System.out.println("Choose the task model��" + chooser.getSelectedFile().getAbsolutePath());
					taskModelFileName = chooser.getSelectedFile().getAbsolutePath();
					text.setText(taskModelFileName);
				}
		}
	});
		text_1 = new Text(compsoite1, SWT.BORDER);
		
		GridData gd_text_1 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1);
		gd_text_1.widthHint = 594;
		text_1.setLayoutData(gd_text_1);
		text_1.setBackground(SWTResourceManager.getColor(240, 248, 255));

		Button btnNewButton_1 = new Button(compsoite1, SWT.NONE);
		GridData gd_btnNewButton_1 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNewButton_1.widthHint = 185;
		btnNewButton_1.setLayoutData(gd_btnNewButton_1);
		btnNewButton_1.setText("Choose Function Model");
		btnNewButton_1.setBackground(SWTResourceManager.getColor(70,130,180));
		btnNewButton_1.setForeground(SWTResourceManager.getColor(255,255,255));
		btnNewButton_1.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
		public void widgetSelected(SelectionEvent e) {
		    String functionModelFileName = "";
			JFrame frame = new JFrame();
			String dir = "C:\\Users\\15857\\workspace-papyrus";
			
			JFileChooser chooser = new JFileChooser();
			chooser.setCurrentDirectory(new File(dir));
			chooser.setDialogTitle("Choose UML model"); 	
		    XMLFileFilter xmlFilter = new XMLFileFilter();   
		    chooser.addChoosableFileFilter(xmlFilter);
		    chooser.setFileFilter(xmlFilter);

			int flag = chooser.showOpenDialog(frame);
			if (flag == JFileChooser.APPROVE_OPTION) {
				System.out.println("Choose the function model��" + chooser.getSelectedFile().getAbsolutePath());
				functionModelFileName = chooser.getSelectedFile().getAbsolutePath();
				text_1.setText(functionModelFileName);
			}
		}
	});
		text_2 = new Text(compsoite1, SWT.BORDER);
		GridData gd_text2 = new GridData(SWT.LEFT, SWT.CENTER, true, false, 2, 1);
		gd_text2.widthHint = 594;
		text_2.setLayoutData(gd_text2);
		text_2.setBackground(SWTResourceManager.getColor(240, 248, 255));

		Button btnNewButton2 = new Button(compsoite1, SWT.NONE);
		GridData gd_btnNewButton2 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNewButton2.widthHint = 185;
		btnNewButton2.setLayoutData(gd_btnNewButton2);
		btnNewButton2.setText("Choose Architecture Model");
		btnNewButton2.setBackground(SWTResourceManager.getColor(70,130,180));
		btnNewButton2.setForeground(SWTResourceManager.getColor(255,255,255));
		btnNewButton2.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		btnNewButton2.addSelectionListener(new SelectionAdapter() {
		public void widgetSelected(SelectionEvent e) {
			    String architectureModelFileName = "";
				JFrame frame = new JFrame();
				String dir = "C:\\Users\\15857\\workspace-papyrus";
				
				JFileChooser chooser = new JFileChooser();
				chooser.setCurrentDirectory(new File(dir));
				chooser.setDialogTitle("Choose UML model"); 	
			    XMLFileFilter xmlFilter = new XMLFileFilter();   
			    chooser.addChoosableFileFilter(xmlFilter);
			    chooser.setFileFilter(xmlFilter);

				int flag = chooser.showOpenDialog(frame);
				if (flag == JFileChooser.APPROVE_OPTION) {
					System.out.println("Choose the architecture model��" + chooser.getSelectedFile().getAbsolutePath());
					architectureModelFileName = chooser.getSelectedFile().getAbsolutePath();
					text_2.setText(architectureModelFileName);
				}
		}
	});
		text_3 = new Text(compsoite1, SWT.BORDER);
		GridData gd_text_3 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1);
		gd_text_3.widthHint = 594;
		text_3.setLayoutData(gd_text_3);
		text_3.setBackground(SWTResourceManager.getColor(240, 248, 255));

		Button btnNewButton_3 = new Button(compsoite1, SWT.NONE);
		GridData gd_btnNewButton_3 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNewButton_3.widthHint = 185;
		btnNewButton_3.setLayoutData(gd_btnNewButton_3);
		btnNewButton_3.setText("Choose Security Model");
		btnNewButton_3.setBackground(SWTResourceManager.getColor(70,130,180));
		btnNewButton_3.setForeground(SWTResourceManager.getColor(255,255,255));
		btnNewButton_3.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		btnNewButton_3.addSelectionListener(new SelectionAdapter() {
		public void widgetSelected(SelectionEvent e) {
		    String securityModelFileName = "";
			JFrame frame = new JFrame();
			String dir = "C:\\Users\\15857\\workspace-papyrus";
			
			JFileChooser chooser = new JFileChooser();
			chooser.setCurrentDirectory(new File(dir));
			chooser.setDialogTitle("Choose UML model"); 	
		    XMLFileFilter xmlFilter = new XMLFileFilter();   
		    chooser.addChoosableFileFilter(xmlFilter);
		    chooser.setFileFilter(xmlFilter);

			int flag = chooser.showOpenDialog(frame);
			if (flag == JFileChooser.APPROVE_OPTION) {
				System.out.println("Choose the architecture model��" + chooser.getSelectedFile().getAbsolutePath());
				securityModelFileName = chooser.getSelectedFile().getAbsolutePath();
				text_3.setText(securityModelFileName);
			}
		}
	});
		new Label(compsoite1, SWT.NONE);
		Button btnNewButton_4 = new Button(compsoite1, SWT.NONE);
		GridData gd_btnNewButton_4 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNewButton_4.widthHint = 455;
		gd_btnNewButton_4.heightHint = 40;
		btnNewButton_4.setLayoutData(gd_btnNewButton_4);
		btnNewButton_4.setText("Generate Alloy Model and Verify");
		btnNewButton_4.setBackground(SWTResourceManager.getColor(255,140,0));
		btnNewButton_4.setForeground(SWTResourceManager.getColor(255,255,224));
		btnNewButton_4.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.BOLD));
		btnNewButton_4.addSelectionListener(new SelectionAdapter() {
		public void widgetSelected(SelectionEvent e) {
			    text_4.setText("");
			    String taskFileName = text.getText();
			    String functionFileName = text_1.getText();
			    String architectureFileName = text_2.getText();
			    String securityFileName = text_3.getText();
				if (taskFileName != "" && functionFileName != "" && architectureFileName != "" && securityFileName !="") {
					try {
				    	List<String> resultList = null;
				    	resultList = UML2Alloy_Verify.main(taskFileName, functionFileName, architectureFileName,securityFileName);

				    	if(resultList!=null && resultList.size()>0) {
				    		for(String res:resultList) {
        		    			text_4.append(res);        				    			
				    		}
				    	}

					} catch (DocumentException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} 
				}
		}
	});
		new Label(compsoite1, SWT.NONE);

		Label lblNewLabel_1 = new Label(compsoite1, SWT.NONE);
		lblNewLabel_1.setAlignment(SWT.CENTER);
		lblNewLabel_1.setText("Verification Results:");
		lblNewLabel_1.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		new Label(compsoite1, SWT.NONE);
		new Label(compsoite1, SWT.NONE);
		
		text_4 = new Text(compsoite1, SWT.BORDER | SWT.READ_ONLY | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL | SWT.WRAP);
		GridData gd_text_4 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1);
		gd_text_4.heightHint = 400;
		gd_text_4.widthHint = 792;
		text_4.setLayoutData(gd_text_4);
		text_4.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.BORDER | SWT.READ_ONLY | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL | SWT.WRAP));
		text_4.setBackground(SWTResourceManager.getColor(255,255,240));

	}

	@Override
	public void setFocus() {
		
	}
}
