package handlers;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.dom4j.DocumentException;

import utils.Task;



import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.alloy4.Err;
import edu.mit.csail.sdg.alloy4compiler.ast.Command;
import edu.mit.csail.sdg.alloy4compiler.ast.Module;
import edu.mit.csail.sdg.alloy4compiler.parser.CompUtil;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Options;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import edu.mit.csail.sdg.alloy4compiler.translator.TranslateAlloyToKodkod;



public class UML2Alloy_Verify {
	public static List<String> main(String TaskModelFileName, String FunctionModelFileName, String ArchitectureModelFileName, String SecurityModelFileName) throws DocumentException, IOException{
//			long time1 = System.currentTimeMillis();
			System.out.println("UML2Alloy");

		    Task task = GetUMLModel.main(TaskModelFileName, FunctionModelFileName, ArchitectureModelFileName, SecurityModelFileName);//Get the UML models.   
		    String fileName = "SCKPISec_Alloy.als";
		    System.out.println("TaskModelFileName:" + TaskModelFileName);
		    System.out.println("FunctionModelFileName:" + FunctionModelFileName);
		    System.out.println("ArchitectureModelFileName:" + ArchitectureModelFileName);
		    System.out.println("SecurityModelFileName:" + SecurityModelFileName);

		    File directory = new File("");
		    String dir = directory.getCanonicalPath() + "\\Alloy" ;
		    System.out.println("dir----" + dir);
		    fileName = dir + "\\" + fileName;
			
			//Generate Alloy models.
			List<String> formalModel = new ArrayList<String>();
			formalModel = GenerateAlloyModel.generateModel(task);
			writeFile(formalModel, fileName);
			
	
//		    long time2 = System.currentTimeMillis();
			//Verification result of the formal model.
			List<String> results = new ArrayList<String>();
			results.add("\r\n--------------------Verification Results--------------------\r\n");
			
			try {
				List<String> a = AlloyVerification.main(fileName);
				results.addAll(a);
			} catch (Err e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return results;
	}
	private static void writeFile(List<String> contentList,String FileName)  {
	      try {
	          BufferedWriter out = new BufferedWriter(new FileWriter(FileName));
	          if(contentList!=null && contentList.size()>0) {
	        	  for(String content:contentList) {
	        		  if(!(content.contains("WARNING: single-value variable") && content.contains("has been stored as a constant"))) {
	        			  //Our method stores some single-value variables which has only one value, for example, "publicData : {DiagnosisData};".
	        			  //This causes NuSMV to output the "WARNING" messages. 
	        			  //In this tool, to avoid displaying irrelevant information in the result list, this type of "WARNING" messages are not in the result list. 
	                      out.write(content);
	                      out.write("\r\n");        			  
	        		  }  			  
	        	  }
	          }
	          out.close();
	      } catch (IOException e) {
	      }
	}
}

