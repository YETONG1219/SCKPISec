package handlers;

import java.util.ArrayList;
import java.util.List;

import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.alloy4.Err;
import edu.mit.csail.sdg.alloy4.ErrorWarning;
import edu.mit.csail.sdg.alloy4compiler.ast.Command;
import edu.mit.csail.sdg.alloy4compiler.ast.Module;
import edu.mit.csail.sdg.alloy4compiler.parser.CompUtil;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Options;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import edu.mit.csail.sdg.alloy4compiler.translator.TranslateAlloyToKodkod;
import edu.mit.csail.sdg.alloy4viz.VizGUI;

/** This class demonstrates how to access Alloy4 via the compiler methods. */

public final class AlloyVerification {

    /*
     * Execute every command in every file.
     *
     * This method parses every file, then execute every command.
     *
     * If there are syntax or type errors, it may throw
     * a ErrorSyntax or ErrorType or ErrorAPI or ErrorFatal exception.
     * You should catch them and display them,
     * and they may contain filename/line/column information.
     */
    public static List<String> main(String filename) throws Err {
    	List<String> results = new ArrayList<String>();
        // The visualizer (We will initialize it to nonnull when we visualize an Alloy solution)
        VizGUI viz = null;

        // Alloy4 sends diagnostic messages and progress reports to the A4Reporter.
        // By default, the A4Reporter ignores all these events (but you can extend the A4Reporter to display the event for the user)
        A4Reporter rep = new A4Reporter() {
            // For example, here we choose to display each "warning" by printing it to System.out
            @Override public void warning(ErrorWarning msg) {
                System.out.print("Relevance Warning:\n"+(msg.toString().trim())+"\n\n");
                System.out.flush();
            }
        };
        // Parse+typecheck the model
        System.out.println("=========== Parsing+Typechecking "+filename+" =============");
        Module world = CompUtil.parseEverything_fromFile(rep, null, filename);

        // Choose some default options for how you want to execute the commands
        A4Options options = new A4Options();

        options.solver = A4Options.SatSolver.SAT4J;
        int i = 0;
        for (Command command: world.getAllCommands()) {
        	i++;
            // Execute the command
            System.out.println("============ Command "+ command +": ============");
            A4Solution ans = TranslateAlloyToKodkod.execute_command(rep, world.getAllReachableSigs(), command, options);
            
            if(!ans.satisfiable()) {
               	if(i==1) {
                	String result = "No counterexample found. Assert f1 {no f:Function| task_failure_fail[f]} may be valid.\r\n\r\n";
                	results.add(result);
            	}
               	if(i==2) {
                	String result = "No counterexample found. Assert f2 {no f:Function| task_failure_wrong_action[f]} may be valid.\r\n\r\n";
                	results.add(result);
            	}
               	if(i==3) {
                	String result = "No counterexample found. Assert f3 {no f:Function| task_failure_data_tamper[f]} may be valid.\r\n\r\n";
                	results.add(result);
            	}
               	if(i==4) {
                	String result = "No counterexample found. Assert f4 {no f:Function| task_failure_data_leakage[f]} may be valid.\r\n\r\n";
                	results.add(result);
            	}
               	if(i==5) {
                	String result = "No counterexample found. Assert f5 {no f:Function| task_failure_data_unavailable[f]} may be valid.\r\n\r\n";
                	results.add(result);
            	}
            }
            if (ans.satisfiable()) {
               	if(i==1) {
                	String result = "Invalid assert found: assert f1 {no f:Function| task_failure_fail[f]}.\r\n"
                			+ "The counterexample is shown in sckpisec_alloy_output.xml.\r\n\r\n"; 
                	results.add(result);
            	}
            	if(i==2) {
                	String result = "Invalid assert found: assert f2 {no f:Function| task_failure_wrong_action[f]}.\r\n"
                			+ "The counterexample is shown in sckpisec_alloy_output.xml.\r\n\r\n"; 
                	results.add(result);
            	}
            	if(i==3) {
                	String result = "Invalid assert found: assert f3 {no  f:Function| task_failure_data_tamper[f]}.\r\n"
                			+ "The counterexample is shown in sckpisec_alloy_output.xml.\r\n\r\n"; 
                	results.add(result);
            	}
            	if(i==4) {
                	String result = "Invalid assert found: assert f4 {no  f:Function| task_failure_data_leakage[f]}.\r\n"
                			+ "The counterexample is shown in sckpisec_alloy_output.xml.\r\n\r\n"; 
                	results.add(result);
            	}
            	if(i==5) {
                	String result = "Invalid assert found: assert f5 {no  f:Function| task_failure_data_unavailable[f]}.\r\n"
                			+ "The counterexample is shown in sckpisec_alloy_output.xml.\r\n\r\n"; 
                	results.add(result);
            	}
            	String name = "sckpisec_alloy_output.xml";
                ans.writeXML(name);
                if (viz==null) {
                    viz = new VizGUI(false, name, null);
                } else {
                    viz.loadXML(name, true);
                }
            }
        }
        System.out.println(results);
		return results;
    }
}