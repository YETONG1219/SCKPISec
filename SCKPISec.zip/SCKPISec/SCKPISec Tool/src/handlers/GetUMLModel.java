package handlers;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;


import utils.Attack;
import utils.Component;
import utils.EnergyFlow;
import utils.Function;
import utils.GetAttackElement;
import utils.GetElementByID;
import utils.InformationFlow;
import utils.MaterialFlow;
import utils.SecurityControl;
import utils.Task;



public class GetUMLModel {
	public static Task main(String TaskModelFileName, String FunctionModelFileName, String ArchitectureModelFileName, String SecurityModelFileName) throws DocumentException{
	   
	   Task task = new Task();
	   task.init();
	   //Get information from the UML models.
	   File functionFile = new File(FunctionModelFileName);
	   SAXReader sax1 = new SAXReader();
	   Document document1 = sax1.read(functionFile);
	   Element root1 = document1.getRootElement();
	   task = readFunctionModel(task, root1, FunctionModelFileName);

	   File architectureFile = new File(ArchitectureModelFileName);
	   SAXReader sax2 = new SAXReader();
	   Document document2 = sax2.read(architectureFile);
	   Element root2 = document2.getRootElement();
	   task = readArchitectureModel(task, root2, ArchitectureModelFileName);
	   
	   System.out.println("read security model...");
	   File securityModelFile = new File(SecurityModelFileName);
	   SAXReader sax3 = new SAXReader();
	   Document document3 = sax3.read(securityModelFile);
	   Element root3 = document3.getRootElement();
	   task = readSecurityModel1(task, root3, SecurityModelFileName);
	   task = readSecurityModel2(task, root3, SecurityModelFileName);

	   
	//Print information in UML models.
	   System.out.println("----Task: id = " + task.getID() + " name = " + task.getName());
	   List<Component> components = task.getComponents();
	   if(components!=null && components.size()>0) {
		   for(Component da:components) {
			   System.out.println("			-component id = "+ da.getID() + " name = " + da.getName());
			   //Security model.
			   List<String> vulnerabilities = da.getVulnerabilities();
			   if(vulnerabilities != null && vulnerabilities.size()>0) {
				   for(String v: vulnerabilities) {
					   System.out.println("			vulnerability = " + v);
				   }
			   }
			   List<Attack> attackList = da.getAttackList();
			   if(attackList != null && attackList.size()>0) {
				   for(Attack a : attackList) {
					   System.out.println("			attackID = " + a.getID());
					   System.out.println("			attackTarget = " + a.getTarget());
					   System.out.println("			attackTargetVulnerability = " + a.getTarget_vulnerability());
					   System.out.println("			attackThreatType = " + a.getThreat_type());
				   }
			   }
			   List<SecurityControl> securityControlList =da.getSecurityControlList();
			   if(securityControlList != null && securityControlList.size()>0) {
				   for(SecurityControl s: securityControlList) {
					   System.out.println("			securityControlID = " + s.getId());
					   List<String> target_vulnerabilities = s.getTargetVulnerabilities();
					   if(target_vulnerabilities!=null && target_vulnerabilities.size()>0) {
						   for(String v:target_vulnerabilities) {
							   System.out.println("			securityControl_vulnerability = " + v);
						   }
					   }
				   }
			   }
		   }
	   }
	//Function model.
	   List<Function> functions = task.getFunctions();
	   if(functions!=null && functions.size()>0) {
		   for(Function e:functions) {
			   System.out.println("----function: id = " + e.getID() + " name = " + e.getName());
			   List<String> components_string = e.getComponents();
			   if(components_string != null && components_string.size()>0) {
				   System.out.println("			function_components = ");

				   for(String c: components_string) {
					   System.out.println("		" + c);
				   }
			   }
		   }
	   }
	//Architecture model.
	   List<InformationFlow> informationFlowList = task.getInformationFlowList();
	   if(informationFlowList != null && informationFlowList.size()>0) {
		   for(InformationFlow i:informationFlowList) {
			   System.out.println(" information flow: information = " + i.getInformation());
			   System.out.println("  component_out = " + i.getComponent_out());
			   System.out.println("  component_in = " + i.getComponent_in());
			   System.out.println("  component_connector = " + i.getComponent_connector());
		   }
	   }
	   List<MaterialFlow> materialFlowList = task.getMaterialFlowList();
	   if(materialFlowList != null && materialFlowList.size()>0) {
		   for(MaterialFlow m:materialFlowList) {
			   System.out.println(" material flow: material = " + m.getMaterial());
			   System.out.println("  component_out = " + m.getComponent_out());
			   System.out.println("  component_in = " + m.getComponent_in());
			   System.out.println("  component_connector = " + m.getComponent_connector());
		   }
	   }
	   List<EnergyFlow> energyFlowList = task.getEnergyFlowList();
	   if(energyFlowList != null && energyFlowList.size()>0) {
		   for(EnergyFlow e:energyFlowList) {
			   System.out.println(" energy flow: energy = " + e.getEnergy());
			   System.out.println("  component_out = " + e.getComponent_out());
			   System.out.println("  component_in = " + e.getComponent_in());
			   System.out.println("  component_connector = " + e.getComponent_connector());
		   }
	   }

	return task;
	}
	public static Task readFunctionModel(Task task, Element node, String fileName) throws DocumentException{
		System.out.println("readFunctionModel");

		if(node.getName().equals("Task")) {
			System.out.println("find task:"+ node.attributeValue("base_Class"));

			if(node.attributeValue("base_Class")!=null) {
				task.setName(node.attributeValue("name"));
				String uml_id = node.attributeValue("base_Class");
				Element e = GetElementByID.getElement(uml_id, fileName, "id");
				if(e != null) {
					String taskID = e.attributeValue("name");
					System.out.println("taskID:" + taskID);

					task.setID(taskID);
				}
				else {
					System.out.println("Error: Cannnot find SCKPISec task.");
				}
			}
		}
		if(node.getName().equals("Function")) {
			Function function = new Function();
			function.init();
			List<String> components = new ArrayList<String>();
		    List<Element> subElements = node.elements();
		    for (Element e : subElements) {
		    	String component = e.getTextTrim();
		    	components.add(component.toLowerCase());
		    }
		    function.setComponents(components);
		    
			if(node.attributeValue("base_Class")!=null) {
				function.setName(node.attributeValue("name"));
				String uml_id = node.attributeValue("base_Class");
				Element e = GetElementByID.getElement(uml_id, fileName, "id");
				if(e != null) {
					String FuncID = e.attributeValue("name");
					function.setID(FuncID);
				}
				else {
					System.out.println("Error: Cannnot find SCKPISec function.");
				}
			}
			List<Function> functions = task.getFunctions();
			functions.add(function);
			task.setFunctions(functions);
		}
		// Recursively iterate through all the child nodes of the current node.
	    List<Element> elementList = node.elements();
	    for (Element e : elementList) {
	 	   task = readFunctionModel(task, e, fileName);
	    }
		return task;
	}
	
	public static Task readArchitectureModel(Task task, Element node, String fileName ) throws DocumentException{
		System.out.println("readArchitectureModel :" + fileName);
		System.out.println("node.getName:" + node.getName());

		if(node.getName().equals("component")) {
			System.out.println("component: " + node.attributeValue("name"));
			Component component = new Component();
			component.init();
			if(node.attributeValue("name")!=null) {
				String componentName = node.attributeValue("name");
				component.setName(componentName);
			}
			else {
				System.out.println("Error: The name of component is null.");
			}
			if(node.attributeValue("base_Component")!=null) {
				System.out.println("Find base_component");
				String uml_id = node.attributeValue("base_Component");
				Element e = GetElementByID.getElement(uml_id, fileName, "id");
				if(e != null) {
					String componentID = e.attributeValue("name").toLowerCase();
					componentID = componentID.toLowerCase();
					component.setID(componentID);
					System.out.println("   id: " + componentID);

				}
				else {
					System.out.println("Error: Cannnot find SCKPISec component.");
				}
			}
			List<Component> components = task.getComponents();
			components.add(component);
			task.setComponents(components);
			
		}
		if(node.getName().equals("InformationFlow")) {
			InformationFlow informationFlow = new InformationFlow();
			if(node.attributeValue("information")!=null) {
				String information = node.attributeValue("information");
				informationFlow.setInformation(information);
			}
			else {
				System.out.println("Error: The information of information flow is null.");

			}
			if(node.attributeValue("connector")!=null) {
				String connector = node.attributeValue("connector").toLowerCase();
				informationFlow.setComponent_connector(connector);
			}
			else {
				System.out.println("Error: The connector of information flow is null.");

			}
			if(node.attributeValue("base_Dependency")!=null) {
				String component_out_name = ""; 
				String component_in_name = "";
				String uml_id = node.attributeValue("base_Dependency");
				Element e = GetElementByID.getElement(uml_id, fileName, "id");
				if(e != null) {
					String component_out_uml_id = e.attributeValue("client");
					String component_in_uml_id = e.attributeValue("supplier");
					Element e1 = GetElementByID.getElement(component_out_uml_id, fileName, "id");
					if(e1 != null) {
						Element component_out_element = e1.getParent();
						component_out_name = component_out_element.attributeValue("name").toLowerCase();
					}
					else {
						System.out.println("Error: Cannnot find component_out.");
					}
					Element e2 = GetElementByID.getElement(component_in_uml_id, fileName, "id");
					if(e2 != null) {
						Element component_in_element = e2.getParent();
						component_in_name = component_in_element.attributeValue("name").toLowerCase();
					}
					else {
						System.out.println("Error: Cannnot find component_in.");
					}
				}
				else {
					System.out.println("Error: Cannnot find SCKPISec information flow.");
				}
				informationFlow.setComponent_out(component_out_name);
				informationFlow.setComponent_in(component_in_name);
			}
			List<InformationFlow> informationFlowList = task.getInformationFlowList();
			informationFlowList.add(informationFlow);
			task.setInformationFlowList(informationFlowList);
		}

		// Recursively iterate through all the child nodes of the current node.
	    List<Element> elementList = node.elements();
	    for (Element e : elementList) {
	 	   task = readArchitectureModel(task, e, fileName);
	    }
		return task;
	}
	
	public static Task readSecurityModel1(Task task, Element node, String fileName) throws DocumentException{
		System.out.println("readSecurityModel1");
		List<Component> components = task.getComponents();
		System.out.println("node: " + node.getName());
		if(node.getName().equals("has_vulnerability")) {
				String uml_id = node.attributeValue("base_Association");
				Element e = GetElementByID.getElement(uml_id, fileName, "id");
				if(e != null) {
					String vs = e.attributeValue("memberEnd").split(" ")[0];
					String cs = e.attributeValue("memberEnd").split(" ")[1];
					Element ve = GetElementByID.getElement(vs, fileName, "id");
					String cve_id = ve.attributeValue("name");
					Element ce = GetElementByID.getElement(cs, fileName, "id");
					String component_id = ce.attributeValue("name").toLowerCase();
					int component_index = getComponentByID(task,component_id);
					Component component = components.get(component_index);
					List<String> vulnerabilityList = component.getVulnerabilities();
					vulnerabilityList.add(cve_id);
					component.setVulnerabilities(vulnerabilityList);
					components.remove(component_index);
					components.add(component);
					task.setComponents(components);
				}
				else {
					System.out.println("Error: Cannnot find SCKPISec vulnerability.");
				}
			}
		if(node.getName().equals("applies")) {
			String uml_id = node.attributeValue("base_Association");
			Element e = GetElementByID.getElement(uml_id, fileName, "id");
			if(e != null) {
				String ss = e.attributeValue("memberEnd").split(" ")[0];
				String cs = e.attributeValue("memberEnd").split(" ")[1];
				Element ve = GetElementByID.getElement(ss, fileName, "id");
				String s_id = ve.attributeValue("name");
				Element ce = GetElementByID.getElement(cs, fileName, "id");
				String component_id = ce.attributeValue("name").toLowerCase();
				int component_index = getComponentByID(task,component_id);
				Component component = components.get(component_index);
				SecurityControl s = new SecurityControl();
				s.init();
				s.setId(s_id);
				List<SecurityControl> securityControlList = component.getSecurityControlList();
				securityControlList.add(s);
				component.setSecurityControlList(securityControlList);
				components.remove(component_index);
				components.add(component);
				task.setComponents(components);
			}
			else {
				System.out.println("Error: Cannnot find SCKPISec security control method.");
			}
		}
		if(node.getName().equals("threatens")) {
			String uml_id = node.attributeValue("base_Association");
			System.out.println("threatens: " + uml_id);
			Element e = GetElementByID.getElement(uml_id, fileName, "id");
			if(e != null) {
				String cs = e.attributeValue("memberEnd").split(" ")[0];
				String as = e.attributeValue("memberEnd").split(" ")[1];
				String component_id = "";
				String a_id ="";
				String threat_type ="";

				Element ae = GetElementByID.getElement(as, fileName, "id");
				if(ae!=null) {
					a_id = ae.attributeValue("name");
					Element attackElement = GetAttackElement.getAttackElement(a_id, fileName, "name"); 
					if(attackElement != null) {
						String attack_uml_id = attackElement.attributeValue("id");
						Element e1 = GetElementByID.getElement(attack_uml_id, fileName, "base_Class"); 
						threat_type = e1.attributeValue("threat_type");
					}
					else {
						System.out.println("Error: Cannnot find SCKPISec attack1.");
					}
				}
				else {
					System.out.println("Error: Cannnot find SCKPISec attack2.");
				}
				Element ce = GetElementByID.getElement(cs, fileName, "id");
				if(ce!=null) {
					 component_id = ce.attributeValue("name").toLowerCase();
				}
				else {
					System.out.println("Error: Cannnot find SCKPISec component.");
				}
				int component_index = getComponentByID(task,component_id);
				if(component_index<0)
					System.out.println("Error: component_id = " + component_id);
				Component component = components.get(component_index);
				Attack attack = new Attack();
				attack.setID(a_id);
				attack.setTarget(component_id);
				attack.setThreat_type(threat_type);
				
				for(Component c: task.getComponents()) {
					System.out.println("Component B = " + c.getID());
				}
				
	

				List<Attack> attackList = component.getAttackList();
				attackList.add(attack);
				component.setAttackList(attackList);
				components.remove(component_index);
				components.add(component);
				task.setComponents(components);
				
				System.out.println("		Component = " + component.getID() + " attack = " + attack.getID());

				for(Component c: task.getComponents()) {
					System.out.println("````Component A = " + c.getID());
				}
			}
			else {
				System.out.println("Error: Cannnot find SCKPISec component.");
			}
		}

		// Recursively iterate through all the child nodes of the current node.
	    List<Element> elementList = node.elements();
	    for (Element e : elementList) {
	 	   task = readSecurityModel1(task, e, fileName);
	    }
		return task;
	}
	public static Task readSecurityModel2(Task task, Element node, String fileName) throws DocumentException{
		System.out.println("readSecurityModel2");
		System.out.println("node: " + node.getName());

		List<Component> components = task.getComponents();
		if(node.getName().equals("mitigates")) {
			System.out.println("mitigates: " + node.attributeValue("base_Association"));

			String uml_id = node.attributeValue("base_Association");
			Element e = GetElementByID.getElement(uml_id, fileName, "id");
			if(e!=null) {
				String vs = e.attributeValue("memberEnd").split(" ")[0];
				String as = e.attributeValue("memberEnd").split(" ")[1];

				Element ve = GetElementByID.getElement(vs, fileName, "id");
				Element ae = GetElementByID.getElement(as, fileName, "id");
				
				String vulnerabilityID = ve.attributeValue("name");
				String securityControlID = ae.attributeValue("name");
				
				System.out.println("vulnerabilityID: " + vulnerabilityID + " securityControlID: " + securityControlID);
				
				
				String s = getSecurityControlByID(task, securityControlID);
				System.out.println("s: "+ s);
				int i = Integer.parseInt(s.split(" ")[0]);
				int j = Integer.parseInt(s.split(" ")[1]);
				
				Component component = components.get(i);
				List<SecurityControl> securityControlList = component.getSecurityControlList();
				SecurityControl securityControl = securityControlList.get(j);
				
				List<String> vulnerabilities = securityControl.getTargetVulnerabilities();
				if(!vulnerabilities.contains(vulnerabilityID))
					vulnerabilities.add(vulnerabilityID);
				securityControl.setTargetVulnerabilities(vulnerabilities);
				securityControlList.remove(j);
				securityControlList.add(securityControl);
				
				component.setSecurityControlList(securityControlList);
				components.remove(i);
				components.add(component);
				task.setComponents(components);
			}
			else {
				System.out.println("Error: Cannnot find SCKPISec vulnerability.");
			}
		}

		if(node.getName().equals("exploits")) {
			String uml_id = node.attributeValue("base_Association");
			Element e = GetElementByID.getElement(uml_id, fileName, "id");
			if(e!=null) {
				String vs = e.attributeValue("memberEnd").split(" ")[0];
				String as = e.attributeValue("memberEnd").split(" ")[1];

				Element ve = GetElementByID.getElement(vs, fileName, "id");
				Element ae = GetElementByID.getElement(as, fileName, "id");
				
				String vulnerabilityID = ve.attributeValue("name");
				String attackID = ae.attributeValue("name");
				attackID = attackID.toLowerCase();
				
				
				System.out.println("vulnerabilityID: " + vulnerabilityID + " attackID: " + attackID);
			
				String s = getAttackByID(task, attackID);
				
				int i = Integer.parseInt(s.split(" ")[0]);
				int j = Integer.parseInt(s.split(" ")[1]);
	
				
				Component component = components.get(i);
				List<Attack> attackList = component.getAttackList();
				Attack attack = attackList.get(j);
				System.out.println("s: " + s);
				System.out.println("	component = " + component.getID() + " attack = " + attack.getID());
				attack.setTarget_vulnerability(vulnerabilityID);
				attackList.remove(j);
				attackList.add(attack);
				
				component.setAttackList(attackList);
				components.remove(i);
				components.add(component);
				task.setComponents(components);
				
				for(Component c: task.getComponents()) {
					System.out.println("c: " + c.getID());
					if(c.getAttackList()!=null && c.getAttackList().size()>0) {
						for(Attack a:c.getAttackList()) {
							System.out.println("		a: " + a.getID());
						}
					}
				}
			}
			else {
				System.out.println("Error: Cannnot find SCKPISec target vulnerability.");
			}
		}

		// Recursively iterate through all the child nodes of the current node.
	    List<Element> elementList = node.elements();
	    for (Element e : elementList) {
	 	   task = readSecurityModel2(task, e, fileName);
	    }
		return task;
	}
	
	public static int getComponentByID(Task task, String c) {
		List<Component> components = task.getComponents();
		int i = 0;
		if(components!=null && components.size()>0) {
			for(Component component: components) {
				if(component.getID().equalsIgnoreCase(c)) {
					return i;
				}
				i++;
			}
		}
		return -1;
	}
	public static String getAttackByID(Task task, String attackID) {
		List<Component> components = task.getComponents();
		int i=0;
		int j=0;
		if(components!=null && components.size()>0) {
			for(Component component: components) {
				List<Attack> attackList = component.getAttackList();
				if(attackList!=null && attackList.size()>0) {
					for(Attack a: attackList) {
						j=0;
						System.out.println("component: " + component.getID() + " attack: " + a.getID());
						System.out.println("i: " + i + " j: " + j);

						if(a.getID().equalsIgnoreCase(attackID)) {
							return i +" "+ j;
						}
						j++;
					}
				}
				i++;
			}
		}
		return "-1";
	}
	public static String getSecurityControlByID(Task task, String c) {
		List<Component> components = task.getComponents();
		int i=0;
		int j=0;
		if(components!=null && components.size()>0) {
			for(Component component: components) {
				List<SecurityControl> securityControlList = component.getSecurityControlList();
				if(securityControlList!=null && securityControlList.size()>0) {
					for(SecurityControl a: securityControlList) {
						j = 0;
						if(a.getId().equalsIgnoreCase(c))
							return i +" "+ j;
						j++;
					}
				}
				i++;
			}
		}
		return "-1";
	}
}
