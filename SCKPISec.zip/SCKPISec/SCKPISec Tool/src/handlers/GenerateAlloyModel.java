package handlers;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import utils.Attack;
import utils.Component;
import utils.EnergyFlow;
import utils.Function;
import utils.InformationFlow;
import utils.MaterialFlow;
import utils.SecurityControl;
import utils.Task;

public class GenerateAlloyModel{
	//Generate the formal model.
	public static List<String> generateModel(Task task) throws IOException{
		List<String> model = new ArrayList<String>();
		String s = "abstract sig Information{}\r\n" + 
				"abstract sig InformationFlow {\r\n" + 
				"information: set Information,\r\n" + 
				"component_in: one Component,\r\n" + 
				"component_out: one Component,\r\n" + 
				"component_connector: one Component\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"abstract sig Energy{}\r\n" + 
				"abstract sig EnergyFlow{\r\n" + 
				"energy: set Energy,\r\n" + 
				"component_in: one Component,\r\n" + 
				"component_out: one Component,\r\n" + 
				"component_connector: one Component\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"abstract sig Material{}\r\n" + 
				"abstract sig MaterialFlow{\r\n" + 
				"material: set Material,\r\n" + 
				"component_in: one Component,\r\n" + 
				"component_out: one Component,\r\n" + 
				"component_connector: one Component\r\n" + 
				"}\r\n";
		model.add(s);
		s = "//Threat modeling.\r\n" + 
				"abstract sig Threat{}\r\n" + 
				"one sig Spoofing extends Threat{}\r\n" + 
				"one sig Tampering extends Threat{}\r\n" + 
				"one sig Repudiation extends Threat{}\r\n" + 
				"one sig Information_disclosure extends Threat{}\r\n" + 
				"one sig Denial_of_service extends Threat{}\r\n" + 
				"one sig Escalation_of_privilege extends Threat{}\r\n" + 
				"\r\n" + 
				"abstract sig CVEVulnerability{}\r\n" + 
				"\r\n" + 
				"abstract sig Attack{\r\n" + 
				"threat_type: one Threat,\r\n" + 
				"target: set Component,\r\n" + 
				"target_vulnerability: one CVEVulnerability\r\n" + 
				"}\r\n";
		model.add(s);
		s = "abstract sig Component{\r\n" + 
				"vulnerabilities: set CVEVulnerability,\r\n" + 
				"dependency_set: set Component \r\n" + 
				"}\r\n" + 
				"abstract sig Function{\r\n" + 
				"components: set Component\r\n" + 
				"}\r\n";
		model.add(s);
		s = "//Dependency definitions \r\n" + 
				"//c1-->c, c depends on c1\r\n" + 
				"pred information_dependency [c : Component, c1 : Component] { \r\n" + 
				"some information_flow: InformationFlow {\r\n" + 
				"((c in information_flow.component_in) and (c1 in information_flow.component_out))or\r\n" + 
				"((c in information_flow.component_connector) and (c1 in information_flow.component_out))or\r\n" + 
				"((c in information_flow.component_in) and (c1 in information_flow.component_connector))\r\n" + 
				"}}\r\n" + 
				"pred energy_dependency [c : Component, c1 : Component] { \r\n" + 
				"some energy_flow: EnergyFlow {\r\n" + 
				"((c in energy_flow.component_in) and (c1 in energy_flow.component_out) )or\r\n" + 
				"((c in energy_flow.component_connector) and (c1 in energy_flow.component_out))or\r\n" + 
				"((c in energy_flow.component_in) and (c1 in energy_flow.component_connector))\r\n" + 
				"}}\r\n" + 
				"pred material_dependency[c: Component, c1: Component] { \r\n" + 
				"some material_flow: InformationFlow {\r\n" + 
				"((c in material_flow.component_in) and (c1 in material_flow.component_out) )or\r\n" + 
				"((c in material_flow.component_connector) and (c1 in material_flow.component_out))or\r\n" + 
				"((c in material_flow.component_in) and (c1 in material_flow.component_connector))\r\n" + 
				"}}\r\n" + 
				"fact { all c,c1: Component | (c1 in c.dependency_set) <=> (information_dependency[c,c1] or energy_dependency[c,c1] or material_dependency[c,c1]) }\r\n" + 
				"//Component failure.\r\n" + 
				"abstract sig component_failure{\r\n" + 
				"omission: set Component,\r\n" + 
				"commission: set Component,\r\n" + 
				"value: set Component,\r\n" + 
				"crash: set Component,\r\n" + 
				"data_leakage: set Component,\r\n" + 
				"data_tamper: set Component,\r\n" + 
				"data_unavailable: set Component\r\n" + 
				"}\r\n";
		model.add(s);
		s = "//Failure_propation.\r\n" + 
				"pred failure_propagation_omission[c1:Component,c:Component]{\r\n" + 
				"c1 in c.^dependency_set and (c1 in component_failure.omission or c1 in component_failure.crash)\r\n" + 
				"}\r\n" + 
				"pred failure_propagation_commission[c1:Component,c:Component]{\r\n" + 
				"c1 in c.^dependency_set and c1 in component_failure.commission\r\n" + 
				"}\r\n" + 
				"pred failure_propagation_value[c1:Component,c:Component]{\r\n" + 
				"c1 in c.^dependency_set and c1 in component_failure.value\r\n" + 
				"}\r\n" + 
				"pred failure_propagation_data_tamper[c1:Component,c:Component]{\r\n" + 
				"c1 in c.^dependency_set and c1 in component_failure. data_tamper \r\n" + 
				"}\r\n" + 
				"pred failure_propagation_data_unavailable[c1:Component,c:Component]{\r\n" + 
				"c1 in c.^dependency_set and c1 in component_failure. data_unavailable \r\n" + 
				"}\r\n";
		model.add(s);
		s = "//Component_failure_omission.\r\n" + 
				"pred component_failure_omission[c : Component] {\r\n" + 
				"some a : Attack{\r\n" + 
				"((c in a.target) and (some v:CVEVulnerability {(v in c.vulnerabilities) and (v in a.target_vulnerability)}) and (Spoofing in a.threat_type  or Tampering in a.threat_type  or Denial_of_service in a.threat_type or Escalation_of_privilege in  a.threat_type))\r\n" + 
				"or(some c1:Component|failure_propagation_omission[c1,c]) \r\n" + 
				"}}\r\n" + 
				"fact{all c: Component | component_failure_omission[c] <=> c in  component_failure.omission}\r\n" + 
				"//Component_failure_commission.\r\n" + 
				"pred component_failure_commission[c : Component] {\r\n" + 
				"some  a : Attack{\r\n" + 
				"((c in a.target) and (some v:CVEVulnerability {(v in c.vulnerabilities) and (v in a.target_vulnerability)}) and (Spoofing in a.threat_type  or Tampering in a.threat_type  or Escalation_of_privilege in  a.threat_type))\r\n" + 
				"or(some c1:Component|failure_propagation_commission[c1,c]) \r\n" + 
				"}}\r\n" + 
				"fact{all c: Component |  component_failure_commission[c] <=> c in  component_failure.commission}\r\n" + 
				"//Component_failure_value.\r\n" + 
				"pred component_failure_value[c : Component] {\r\n" + 
				"some  a : Attack{\r\n" + 
				"((c in a.target) and (some v:CVEVulnerability{(v in c.vulnerabilities) and (v in a.target_vulnerability)}) and (Spoofing in a.threat_type  or Tampering in a.threat_type  or Escalation_of_privilege in  a.threat_type))\r\n" + 
				"or(some c1:Component|failure_propagation_value[c1,c]) \r\n" + 
				"}}\r\n" + 
				"fact{all c: Component |  component_failure_value[c] <=> c in  component_failure.value}\r\n" + 
				"//Component_failure_crash.\r\n" + 
				"pred component_failure_crash[c : Component] {\r\n" + 
				"some  a : Attack{\r\n" + 
				"((c in a.target) and (some v :CVEVulnerability {(v in c.vulnerabilities) and (v in a.target_vulnerability)}) and (Spoofing in a.threat_type  or Tampering in a.threat_type or Denial_of_service in a.threat_type or Escalation_of_privilege in  a.threat_type))\r\n" + 
				"}}\r\n" + 
				"fact{all c: Component |  component_failure_crash[c] <=> c in  component_failure.crash}\r\n" + 
				"//Component_failure_data_leakage.\r\n" + 
				"pred component_failure_data_leakage[c : Component] {\r\n" + 
				"some  a : Attack{\r\n" + 
				"((c in a.target) and (some v:CVEVulnerability {(v in c.vulnerabilities) and (v in a.target_vulnerability)}) and (Information_disclosure in a.threat_type or Escalation_of_privilege in  a.threat_type))\r\n" + 
				"}}\r\n" + 
				"fact{all c: Component |  component_failure_data_leakage[c] <=> c in  component_failure.data_leakage}\r\n" + 
				"//Component_failure_data_tamper.\r\n" + 
				"pred component_failure_data_tamper[c : Component] {\r\n" + 
				"some  a : Attack{\r\n" + 
				"((c in a.target) and (some v:CVEVulnerability {(v in c.vulnerabilities) and (v in a.target_vulnerability)}) and (Tampering in a.threat_type or Escalation_of_privilege in  a.threat_type))\r\n" + 
				"or(some c1:Component|failure_propagation_data_tamper[c1,c])\r\n" + 
				"}}\r\n" + 
				"fact{all c: Component |  component_failure_data_tamper[c] <=> c in  component_failure.data_tamper}\r\n" + 
				"//Component_failure_data_unavailable.\r\n" + 
				"pred component_failure_data_unavailable[c : Component] {\r\n" + 
				"some  a : Attack{\r\n" + 
				"((c in a.target) and (some v:CVEVulnerability {(v in c.vulnerabilities) and (v in a.target_vulnerability)}) and (Denial_of_service in a.threat_type or Escalation_of_privilege in  a.threat_type))\r\n" + 
				"or(some c1:Component|failure_propagation_data_unavailable[c1,c])\r\n" + 
				"}}\r\n" + 
				"fact{all c: Component |  component_failure_data_unavailable[c] <=> c in  component_failure.data_unavailable}\r\n";
		model.add(s);
		s = "//Task failure.\r\n" + 
				"pred task_failure_fail[f : Function]{\r\n" + 
				"some c: Component{(c in f.components) and (component_failure_omission[c] or component_failure_crash[c])}\r\n" + 
				"}\r\n" + 
				"pred task_failure_wrong_action[f : Function]{\r\n" + 
				"some c: Component{(c in f.components) and (component_failure_value[c] or component_failure_commission[c])}\r\n" + 
				"}\r\n" + 
				"pred task_failure_data_tamper[f : Function]{\r\n" + 
				"some c: Component{(c in f.components) and (component_failure_data_tamper[c])}\r\n" + 
				"}\r\n" + 
				"pred task_failure_data_leakage[f : Function]{\r\n" + 
				"some c: Component{(c in f.components) and (component_failure_data_leakage[c])}\r\n" + 
				"}\r\n" + 
				"pred task_failure_data_unavailable[f : Function]{\r\n" + 
				"some c: Component{(c in f.components) and (component_failure_data_unavailable[c])}\r\n" + 
				"}\r\n";
		model.add(s);
		
		int informationFlow_i = 1, materialFlow_i = 1, energyFlow_i = 1;
		

		List<InformationFlow> informationFlowList = task.getInformationFlowList();
		if(informationFlowList!=null && informationFlowList.size()>0) {
			for(InformationFlow informationFlow: informationFlowList) {
				String component_in = informationFlow.getComponent_in();
				String component_out = informationFlow.getComponent_out();
				String component_connector = informationFlow.getComponent_connector();
				String information = informationFlow.getInformation();
				String information_flow_text = "one sig information_flow"+ informationFlow_i +" extends InformationFlow{}{\r\n" + 
						"information = "+ information +"\r\n" + 
						"component_out = "+ component_out +"\r\n" + 
						"component_in = "+ component_in +"\r\n" + 
						"component_connector = "+ component_connector + "_" + informationFlow_i +"\r\n" + 
						"}\r\n";
				String information_text = "one sig " + information + " extends Information{}\r\n";
				if(!model.contains(information_text))
					model.add(information_text);
				model.add(information_flow_text);
				
				informationFlow_i++;
			}
		
		}
		
		List<MaterialFlow> materialFlowList = task.getMaterialFlowList();
		if(materialFlowList!=null && materialFlowList.size()>0) {
			for(MaterialFlow materialFlow: materialFlowList) {
				String component_in = materialFlow.getComponent_in();
				String component_out = materialFlow.getComponent_out();
				String component_connector = materialFlow.getComponent_connector();
				String material = materialFlow.getMaterial();
				String material_flow_text = "one sig material_flow"+ materialFlow_i +" extends MaterialFlow{}{\r\n" + 
						"material = "+ material +"\r\n" + 
						"component_out = "+ component_out +"\r\n" + 
						"component_in = "+ component_in +"\r\n" + 
						"component_connector = "+ component_connector + "_" + materialFlow_i +"\r\n" + 
						"}\r\n";
				String material_text = "one sig " + material + " extends Material{}\r\n";
				if(!model.contains(material_text))
					model.add(material_text);
				model.add(material_flow_text);
				materialFlow_i++;
			}
			
		}
		List<EnergyFlow> energyFlowList = task.getEnergyFlowList();
		if(energyFlowList!=null && energyFlowList.size()>0) {
			for(EnergyFlow energyFlow: energyFlowList) {
				String component_in = energyFlow.getComponent_in();
				String component_out = energyFlow.getComponent_out();
				String component_connector = energyFlow.getComponent_connector();
				String energy = energyFlow.getEnergy();
				String energy_flow_text = "one sig energy_flow"+ energyFlow_i +" extends EnergyFlow{}{\r\n" + 
						"energy = "+ energy +"\r\n" + 
						"component_out = "+ component_out +"\r\n" + 
						"component_in = "+ component_in +"\r\n" + 
						"component_connector = "+ component_connector+ "_" + energyFlow_i +"\r\n" + 
						"}\r\n";
				String energy_text = "one sig " + energy + " extends Energy{}\r\n";
				if(!model.contains(energy_text))
					model.add(energy_text);
				model.add(energy_flow_text);
				energyFlow_i++;
			}
		}
		

		
		List<Component> components = task.getComponents();
		if(components!=null && components.size()>0) {
			for(Component component:components) {
				List<String> vulnerabilities = component.getVulnerabilities();
				if(vulnerabilities!=null && vulnerabilities.size()>0) {
					for(String v: vulnerabilities) {
						String vulnerability_text = "one sig "+ v.replace("-", "_") +" extends CVEVulnerability{}\r\n";
						model.add(vulnerability_text);
					}
				}
				List<SecurityControl> securityControlList = component.getSecurityControlList();
				String c = component.getID();
				String component_text = "";
				boolean flag = false;
				if(informationFlowList!= null && informationFlowList.size()>0) {
					int i = 1;
					int flow_index = 0;
					for(InformationFlow in_flow: informationFlowList) {
						if(c.equalsIgnoreCase(in_flow.getComponent_connector())) {
							flag = true;
							component_text = component_text + "one sig " +  c + "_" + i + " extends Component{}{\r\n";
							in_flow.setComponent_connector(c + "_" + i);
							informationFlowList.set(flow_index, in_flow);
							flow_index++;
							i++;
							for(SecurityControl sc: securityControlList) {
								List<String> sc_target_vulnerabilities = sc.getTargetVulnerabilities();
								if(sc_target_vulnerabilities !=null && sc_target_vulnerabilities.size()>0) {
									for(String v:sc_target_vulnerabilities) {
										if(vulnerabilities.contains(v)) {
											vulnerabilities.remove(v);
										}
									}
								}
							}
							if(vulnerabilities!=null && vulnerabilities.size()>0) {
								component_text = component_text + "vulnerabilities = ";
								for(String v: vulnerabilities) {
									v = v.replace("-", "_");
									component_text = component_text + v + " + ";
								}
								component_text = component_text.substring(0,component_text.length() - 3) + "\r\n}\r\n";
							}
							else {
								component_text = component_text + "no vulnerabilities\r\n}\r\n";
							}
						}
					}
				}
				  if(materialFlowList!= null && materialFlowList.size()>0) {
					int flow_index = 0;
					int i = 1;
					for(MaterialFlow ma_flow: materialFlowList) {
						if(c.equalsIgnoreCase(ma_flow.getComponent_connector())) {
							flag = true;
							component_text = component_text + "one sig " +  c + "_" + i + " extends Component{}{\r\n";
							ma_flow.setComponent_connector(c + "_" + i);
							materialFlowList.set(flow_index, ma_flow);
							i++;
							flow_index++;
							for(SecurityControl sc: securityControlList) {
								List<String> sc_target_vulnerabilities = sc.getTargetVulnerabilities();
								if(sc_target_vulnerabilities !=null && sc_target_vulnerabilities.size()>0) {
									for(String v:sc_target_vulnerabilities) {
										if(vulnerabilities.contains(v)) {
											vulnerabilities.remove(v);
										}
									}
								}
							}
							if(vulnerabilities!=null && vulnerabilities.size()>0) {
								component_text = component_text + "vulnerabilities = ";
								for(String v: vulnerabilities) {
									component_text = component_text + v + " + ";
								}
								component_text = component_text.substring(0,component_text.length() - 3) + "\r\n}\r\n";
							}
							else {
								component_text = component_text + "no vulnerabilities\r\n}\r\n";
							}
						}
					}
				}
				  if (energyFlowList!= null && energyFlowList.size()>0) {
					int i = 1;
					int flow_index = 0;
					for(EnergyFlow en_flow: energyFlowList) {
						if(c.equalsIgnoreCase(en_flow.getComponent_connector())) {
							flag = true;
							component_text = component_text + "one sig " +  c + "_" + i + " extends Component{}{\r\n";
							en_flow.setComponent_connector(c + "_" + i);
							energyFlowList.set(flow_index, en_flow);
							flow_index++;
							i++;
							for(SecurityControl sc: securityControlList) {
								List<String> sc_target_vulnerabilities = sc.getTargetVulnerabilities();
								if(sc_target_vulnerabilities !=null && sc_target_vulnerabilities.size()>0) {
									for(String v:sc_target_vulnerabilities) {
										if(vulnerabilities.contains(v)) {
											vulnerabilities.remove(v);
										}
									}
								}
							}
							if(vulnerabilities!=null && vulnerabilities.size()>0) {
								component_text = component_text + "vulnerabilities = ";
								for(String v: vulnerabilities) {
									v = v.replace("-", "_");
									component_text = component_text + v + " + ";
								}
								component_text = component_text.substring(0,component_text.length() - 3) + "\r\n}\r\n";
							}
							else {
								component_text = component_text + "no vulnerabilities\r\n}\r\n";
							}
						}
					}
				}
				  if(!flag) {
					component_text = "one sig " + c + " extends Component{}{\r\n";

					for(SecurityControl sc: securityControlList) {
						List<String> sc_target_vulnerabilities = sc.getTargetVulnerabilities();
						if(sc_target_vulnerabilities !=null && sc_target_vulnerabilities.size()>0) {
							for(String v:sc_target_vulnerabilities) {
								if(vulnerabilities.contains(v)) {
									vulnerabilities.remove(v);
								}
							}
						}
					}
					if(vulnerabilities!=null && vulnerabilities.size()>0) {
						component_text = component_text + "vulnerabilities = ";
						for(String v: vulnerabilities) {
							v = v.replace("-", "_");
							component_text = component_text + v + " + ";
						}
						component_text = component_text.substring(0,component_text.length() - 3) + "\r\n}\r\n";
					}
					else {
						component_text = component_text + "no vulnerabilities\r\n}\r\n";
					}
				  }
				model.add(component_text);
				//Attack.
				List<Attack> attackList = component.getAttackList();
				if(attackList!=null && attackList.size()>0) {
					for(Attack attack: attackList) {

						String attackID = attack.getID();
						String threat_type = attack.getThreat_type();
						String target = attack.getTarget();
						String targets = "";
						if(informationFlowList!= null && informationFlowList.size()>0) {
							int i = 1;
							for(InformationFlow in_flow: informationFlowList) {
								if(in_flow.getComponent_connector().contains(target)) {
									targets = targets + in_flow.getComponent_connector() + " + ";
									i++;
								}
							}
							if(targets.contains(" + "))
								targets = targets.substring(0,targets.length() - 3);
						}
						if(materialFlowList!= null && materialFlowList.size()>0) {
							for(MaterialFlow ma_flow: materialFlowList) {
								if(ma_flow.getComponent_connector().contains(target)) {
									targets = targets + ma_flow.getComponent_connector() + " + ";
								}
							}
							if(targets.contains(" + "))
								targets = targets.substring(0,targets.length() - 3);

						}
						if(energyFlowList!= null && energyFlowList.size()>0) {
							for(EnergyFlow en_flow: energyFlowList) {
								if(en_flow.getComponent_connector().contains(target)) {
									targets = targets + en_flow.getComponent_connector() + " + ";
								}
							}
							if(targets.contains(" + "))
								targets = targets.substring(0,targets.length() - 3);
						}
						String target_vulnerability = attack.getTarget_vulnerability();
						String attack_text = "";
						if(targets != "") {
							attack_text = "one sig "+  attackID +" extends Attack{}{\r\n" + 
									"threat_type = " + threat_type + "\r\n" + 
									"target = " + targets + "\r\n" + 
									"target_vulnerability= " + target_vulnerability.replace("-", "_") + "\r\n" + 
									"}\r\n";		
						}
						else {
							attack_text = "one sig "+  attackID +" extends Attack{}{\r\n" + 
									"threat_type = " + threat_type + "\r\n" + 
									"target = " + target + "\r\n" + 
									"target_vulnerability= " + target_vulnerability.replace("-", "_") + "\r\n" + 
									"}\r\n";	
						}
						model.add(attack_text);
					}
				}

			}

		}
		List<Function> functionList = task.getFunctions();
		if(functionList!=null && functionList.size()>0) {
			for(Function function:functionList) {
				boolean in_flag = false;
				boolean ma_flag = false;
				boolean en_flag = false;

				function.getID();
				String function_text = "one sig "+ function.getID() +" extends Function{}";
				List<String> componentList = function.getComponents();
				List<String> componentList_new = new ArrayList<String>();
				if(componentList!=null && componentList.size()>0) {
					int i = 0;
					for(String c: componentList) {
						boolean flag = false;
						if(informationFlowList!= null && informationFlowList.size()>0) {
							in_flag = true;
							for(InformationFlow in_flow: informationFlowList) {
								String c_in = in_flow.getComponent_in();
								String c_out = in_flow.getComponent_out();
								String c_connector = in_flow.getComponent_connector();
								if(componentList.contains(c_in) && componentList.contains(c_out)&& c_connector.contains(c)) {
									componentList_new.add(c_connector);
									flag = true;
								}
							}
						}
					   if(materialFlowList!= null && materialFlowList.size()>0) {
							ma_flag = true;
							for(MaterialFlow ma_flow: materialFlowList) {
								String c_in = ma_flow.getComponent_in();
								String c_out = ma_flow.getComponent_out();
								String c_connector = ma_flow.getComponent_connector();
								if(componentList.contains(c_in) && componentList.contains(c_out)&& c_connector.contains(c)) {
									componentList_new.add(c_connector);
									flag = true;
								}
							}
						}
					  if (energyFlowList!= null && energyFlowList.size()>0) {
							en_flag =true;
							for(EnergyFlow en_flow: energyFlowList) {
								String c_in = en_flow.getComponent_in();
								String c_out = en_flow.getComponent_out();
								String c_connector = en_flow.getComponent_connector();
								if(componentList.contains(c_in) && componentList.contains(c_out)&& c_connector.contains(c)) {
									componentList_new.add(c_connector);
									flag = true;								}
							}
					 	}
					  if(!flag) {
						  componentList_new.add(c);
					  }
					  i++;
					}
					function_text = function_text + "{\r\ncomponents = ";
					for(String c: componentList_new) {
						function_text = function_text + c + " + ";
					}
					if(function_text.contains(" + "))
						function_text = function_text.substring(0,function_text.length() - 3) + "\r\n";
					if(!in_flag) {
						function_text = function_text + "no InformationFlow\r\n";
					}
					if(!ma_flag) {
						function_text = function_text + "no MaterialFlow\r\n";
					}
					if(!en_flag) {
						function_text = function_text + "no EnergyFlow\r\n";
					}
					function_text = function_text + "}\r\n";
					model.add(function_text);	
				}
			}
		}
		String failure_text = "//Task failure.\r\n" + 
				"assert f1 {no f:Function| task_failure_fail[f]}\r\n" + 
				"assert f2 {no f:Function| task_failure_wrong_action[f]}\r\n" + 
				"assert f3 {no f:Function| task_failure_data_tamper[f]}\r\n" + 
				"assert f4 {no f:Function| task_failure_data_leakage[f]}\r\n" + 
				"assert f5 {no f:Function| task_failure_data_unavailable[f]}\r\n" + 
				"check f1\r\n" + 
				"check f2\r\n" + 
				"check f3\r\n" + 
				"check f4\r\n" + 
				"check f5\r\n";
		model.add(failure_text);
	return model;
	}
}

	

