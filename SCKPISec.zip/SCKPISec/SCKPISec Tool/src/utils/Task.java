package utils;

import java.util.ArrayList;
import java.util.List;

public class Task  {
	private String name;
	private String id;
	private List<Function> functions; 
	private List<InformationFlow> informationFlowList;
	private List<MaterialFlow> materialFlowList;
	private List<EnergyFlow> energyFlowList;
	private List<Component> components; 
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getID() {
		return id;
	}
	public void setID(String id) {
		this.id = id;
	}
	
	public List<Function> getFunctions() {
		return functions;
	}
	public void setFunctions(List<Function> functions) {
		this.functions = functions;
	}
	
	
	public List<InformationFlow> getInformationFlowList() {
		return informationFlowList;
	}
	public void setInformationFlowList(List<InformationFlow> informationFlowList) {
		this.informationFlowList = informationFlowList;
	}
	
	public List<MaterialFlow> getMaterialFlowList() {
		return materialFlowList;
	}
	public void setMaterialFlowList(List<MaterialFlow> materialFlowList) {
		this.materialFlowList = materialFlowList;
	}
	
	public List<EnergyFlow> getEnergyFlowList() {
		return energyFlowList;
	}
	public void setEnergyFlowList(List<EnergyFlow> energyFlowList) {
		this.energyFlowList = energyFlowList;
	}
	public List<Component> getComponents() {
		return components;
	}
	public void setComponents(List<Component> components) {
		this.components = components;
	}
	public void init() {
		List<Function> functions = new ArrayList<Function>();
		setFunctions(functions);
		List<InformationFlow> informationFlowList = new ArrayList<InformationFlow>();
		setInformationFlowList(informationFlowList);
		List<MaterialFlow> materialFlowList = new ArrayList<MaterialFlow>();
		setMaterialFlowList(materialFlowList);
		List<EnergyFlow> energyFlowList = new ArrayList<EnergyFlow>();
		setEnergyFlowList(energyFlowList);
		List<Component> components = new ArrayList<Component>();
		setComponents(components);
	}
}