package utils;

import java.util.ArrayList;
import java.util.List;

public class Component  {
	private String name;
	private String id;
	private List<String> vulnerabilities; 
	private List<SecurityControl> securityControlList;
	private List<Attack> attackList;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getID() {
		return id;
	}
	public void setID(String id) {
		this.id = id;
	}
	
	public List<String> getVulnerabilities() {
		return vulnerabilities;
	}
	public void setVulnerabilities(List<String> vulnerabilities) {
		this.vulnerabilities = vulnerabilities;
	}
	
	public List<SecurityControl> getSecurityControlList() {
		return securityControlList;
	}
	public void setSecurityControlList(List<SecurityControl> securityControlList) {
		this.securityControlList = securityControlList;
	}
	
	public List<Attack> getAttackList() {
		return attackList;
	}
	public void setAttackList(List<Attack> attackList) {
		this.attackList = attackList;
	}
	
	public void init() {
		List<String> vulnerabilities = new ArrayList<String>();
		setVulnerabilities(vulnerabilities);
		
		List<SecurityControl> securityControlList = new ArrayList<SecurityControl>();
		setSecurityControlList(securityControlList);
		
		List<Attack> attackList = new ArrayList<Attack>();
		setAttackList(attackList);
	}
}