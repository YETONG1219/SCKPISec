package utils;

import java.util.ArrayList;
import java.util.List;

public class SecurityControl  {
	private String id;
	private String description;
	private String cost;
	private List<String> target_vulnerabilities;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	public List<String> getTargetVulnerabilities() {
		return target_vulnerabilities;
	}
	public void setTargetVulnerabilities(List<String> target_vulnerabilities) {
		this.target_vulnerabilities = target_vulnerabilities;
	}
	public void init() {
		List<String> target_vulnerabilities = new ArrayList<String>();
		setTargetVulnerabilities(target_vulnerabilities);
	}
}