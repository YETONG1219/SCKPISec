package utils;

public class Attack  {
	private String threat_type; 
	private String target; 
	private String target_vulnerability; 
	private String name;
	private String id;
	
	public String getThreat_type() {
		return threat_type;
	}
	public void setThreat_type(String threat_type) {
		this.threat_type = threat_type;
	}
	
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	
	public String getTarget_vulnerability() {
		return target_vulnerability;
	}
	public void setTarget_vulnerability(String target_vulnerability) {
		this.target_vulnerability = target_vulnerability;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getID() {
		return id;
	}
	public void setID(String id) {
		this.id = id;
	}
}