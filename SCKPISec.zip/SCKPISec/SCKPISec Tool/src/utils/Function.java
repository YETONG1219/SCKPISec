package utils;

import java.util.ArrayList;
import java.util.List;

public class Function  {
	private String name;
	private String id;
	private List<String> components;

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getID() {
		return id;
	}
	public void setID(String id) {
		this.id = id;
	}
	
	public List<String> getComponents() {
		return components;
	}
	public void setComponents(List<String> components) {
		this.components = components;
	}
	
	public void init() {
		List<String> components = new ArrayList<String>();
		setComponents(components);
	}
}