package utils;

public class MaterialFlow  {
	private String material; 
	private String component_out; 
	private String component_in; 
	private String component_connector;
	
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	
	public String getComponent_out() {
		return component_out;
	}
	public void setComponent_out(String component_out) {
		this.component_out = component_out;
	}
	
	public String getComponent_in() {
		return component_in;
	}
	public void setComponent_in(String component_in) {
		this.component_in = component_in;
	}
	
	public String getComponent_connector() {
		return component_connector;
	}
	public void setComponent_connector(String component_connector) {
		this.component_connector = component_connector;
	}
	
}