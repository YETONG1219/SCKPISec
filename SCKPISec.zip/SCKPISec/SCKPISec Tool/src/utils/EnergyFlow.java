package utils;

public class EnergyFlow  {
	private String energy; 
	private String component_out; 
	private String component_in; 
	private String component_connector;
	
	public String getEnergy() {
		return energy;
	}
	public void setEnergy(String energy) {
		this.energy = energy;
	}
	
	public String getComponent_out() {
		return component_out;
	}
	public void setComponent_out(String component_out) {
		this.component_out = component_out;
	}
	
	public String getComponent_in() {
		return component_in;
	}
	public void setComponent_in(String component_in) {
		this.component_in = component_in;
	}
	
	public String getComponent_connector() {
		return component_connector;
	}
	public void setComponent_connector(String component_connector) {
		this.component_connector = component_connector;
	}
	
}